# Security Policy

## Reporting a Vulnerability

If you believe you have found a security vulnerability in llmware, we encourage you to let us know right away. We will investigate all reports and do our best to quickly fix the problem.

Please report security issues by sending an email to security@aibloks.com.

Do __not__ submit an issue ticket or pull request or otherwise publicly disclose the issue.

After receiving your email, we will assess respond as soon as possible and share what we plan to do.
